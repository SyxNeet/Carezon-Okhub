<?php
$section_special_offer = get_field('section_special_offer');
// var_dump($section_special_offer);
?>
<section class="special-offer-container">
  <img
    class="special-offer-container__background-image"
    src="https://carezone.okhub-tech.com/wp-content/uploads/2025/10/bg-special-offer.webp"
    alt="Special Offer Background" />
  <div class="special-offer-container__background-overlay"></div>
  <!-- <img class="special-offer-container__background-overlay-2" src="test.png"/> -->

  <div class="special-offer">
    <div class="special-offer__text">
      <?php echo $section_special_offer['title_pc']; ?>
    </div>


    <div class="special-offer__list">
      <div class="swiper">
        <div class="swiper-wrapper">
          <!-- Slide 1 -->
          <?php foreach ($section_special_offer['offers'] as $item) { ?>
            <div class="swiper-slide">
              <div class="special-offer__list-container">
                <div
                  class="special-offer__list-container-content card-content">
                  <div class="special-offer__list-container-content-top">
                    <div
                      class="special-offer__list-container-content-top-head">
                      <div
                        class="special-offer__list-container-content-top-head-calendar">
                        <p
                          class="special-offer__list-container-content-top-head-calendar-day">
                          <?= date('d', strtotime($item['date_start'])); ?>
                        </p>
                        <p
                          class="special-offer__list-container-content-top-head-calendar-month">
                          Tháng <?= date('m', strtotime($item['date_start'])); ?>
                        </p>
                      </div>
                      <p
                        class="special-offer__list-container-content-top-head-title">
                        <?= $item['name']; ?>
                      </p>
                    </div>
                    <div
                      class="special-offer__list-container-content-top-body">
                      <div
                        class="special-offer__list-container-content-top-body-row">
                        <p
                          class="special-offer__list-container-content-top-body-row-text">
                          Giờ mở cửa:
                        </p>
                        <p
                          class="special-offer__list-container-content-top-body-row-time">
                          <?= $item['time_open']; ?>
                        </p>
                      </div>
                      <p
                        class="special-offer__list-container-content-top-body-text">
                        <?= $item['description']; ?>
                      </p>
                    </div>
                  </div>
                  <div class="special-offer__list-container-content-bottom">
                    <div
                      class="special-offer__list-container-content-bottom-head">
                      <div
                        class="special-offer__list-container-content-bottom-head-bg"></div>
                      <div
                        class="special-offer__list-container-content-bottom-head-progress"></div>
                      <p
                        class="special-offer__list-container-content-bottom-head-text">
                        HẾT HẠN NGÀY <?= date('d/m/Y', strtotime($item['date_end'])); ?>
                      </p>
                    </div>
                    <div
                      class="special-offer__list-container-content-bottom-body">
                      <div
                        class="special-offer__list-container-content-bottom-body-service">
                        <div
                          class="special-offer__list-container-content-bottom-body-service-row">
                          <p
                            class="special-offer__list-container-content-bottom-body-service-row-text">
                            Giá dịch vụ :
                          </p>
                          <p
                            class="special-offer__list-container-content-bottom-body-service-row-price">
                            <?= number_format($item['price'], 0, ',', '.'); ?> đ
                          </p>
                        </div>
                        <p
                          class="special-offer__list-container-content-bottom-body-service-row-text">
                          <?= $item['slot']; ?>
                        </p>
                      </div>
                      <div
                        class="special-offer__list-container-content-bottom-body-button">
                        <button
                          class="booking__form-option-button"
                          type="submit">
                          <p class="booking__form-option-button-text">
                            Đặt chỗ ngay
                          </p>
                          <img
                            data-no-lazy="1"
                            class="booking__form-option-button-icon"
                            src="https://carezone.okhub-tech.com/wp-content/uploads/2025/10/icon-button-1.webp"
                            alt="Icon Button" />
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
                <div
                  class="special-offer__list-container-content-image img-container">
                  <?= wp_get_attachment_image($item['thumb'], 'full'); ?>
                  <div
                    class="special-offer__list-container-content-image-overlay"></div>
                  <div
                    class="special-offer__list-container-content-image-content">
                    <p
                      class="special-offer__list-container-content-image-content-title">
                      <?= $item['name']; ?>
                    </p>
                    <div
                      class="special-offer__list-container-content-image-content-progress">
                      <div
                        class="special-offer__list-container-content-image-content-progress-bg"></div>
                      <div
                        class="special-offer__list-container-content-image-content-progress-progress"></div>
                      <p
                        class="special-offer__list-container-content-image-content-progress-text">
                        HẾT HẠN NGÀY <?= date('d/m/Y', strtotime($item['date_end'])); ?>
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          <?php } ?>
        </div>
      </div>
    </div>
  </div>
</section>