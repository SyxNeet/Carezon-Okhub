// import gsap from "gsap";
// import ScrollTrigger from "gsap/ScrollTrigger";

// Register ScrollTrigger plugin
gsap.registerPlugin(ScrollTrigger);

const pcSwiper = {
  // Convert rem to pixels
  convertRem(rem) {
    var rootFontSize =
      parseFloat(getComputedStyle(document.documentElement).fontSize) || 16;
      return rem * rootFontSize;
  },

  // Animation function for Swiper
  animation(swiper, activeIndex) {
      if (!swiper || !swiper.slides) return;

      var slides = Array.from(swiper.slides);
      var containerWidth = swiper.width;
      var activeWidth = Math.floor(containerWidth * 0.5167); // 51.67%
      var inactiveWidth = Math.floor(containerWidth * 0.22665); // 22.665%

      // Map selectors to existing structure
      var cardContainers = slides.map(function (slide) {
      return slide.querySelectorAll(".special-offer__list-container");
      });
      var cardContents = slides.map(function (slide) {
      return slide.querySelectorAll(".special-offer__list-container-content");
      });
      var imgContainers = slides.map(function (slide) {
      return slide.querySelectorAll(
        ".special-offer__list-container-content-image"
      );
      });
      var imgOverlays = slides.map(function (slide) {
      return slide.querySelectorAll(
        ".special-offer__list-container-content-image-overlay"
      );
      });
      var imgTextContents = slides.map(function (slide) {
      return slide.querySelectorAll(
        ".special-offer__list-container-content-image-content"
      );
      });

      gsap
        .timeline({})
        .to(slides, {
          width: function (index) {
          return activeIndex === index
            ? activeWidth + "px"
            : inactiveWidth + "px";
          },
          background: function (index) {
          return activeIndex === index ? "#fff" : "transparent";
          },
          duration: 1.5,
        ease: "power3.out",
        })
        .to(
          cardContainers,
          {
            paddingTop: (index) => {
            return activeIndex === index ? pcSwiper.convertRem(1.1875) + "px" : 0;
            },
            paddingBottom: (index) => {
            return activeIndex === index ? pcSwiper.convertRem(1.1875) + "px" : 0;
            },
            paddingRight: (index) => {
            return activeIndex === index ? pcSwiper.convertRem(1.1875) + "px" : 0;
            },
            paddingLeft: (index) => {
            return activeIndex === index ? pcSwiper.convertRem(1.5) + "px" : 0;
            },
            duration: 0.6,
          ease: "power4.out",
          },
        "<"
        )
        .to(
          cardContents,
          {
            autoAlpha: function (index) {
              return activeIndex === index ? 1 : 0;
            },
            duration: 0.3,
          ease: "power2.out",
          },
        "<"
        )
        .to(
          imgContainers,
          {
            width: function (index) {
              return activeIndex === index ? "39%" : "100%";
            },
            borderRadius: (index) => {
            return activeIndex === index
              ? pcSwiper.convertRem(0.75) + "px"
              : pcSwiper.convertRem(1.5) + "px";
            },
            duration: 0.8,
          ease: "power3.out",
          },
        "<"
        )
        .to(
          imgOverlays,
          {
            autoAlpha: function (index) {
              return activeIndex === index ? 0 : 1;
            },
            duration: 0.3,
          ease: "power2.out",
          },
        "<"
        )
        .to(
          imgTextContents,
          {
            autoAlpha: function (index) {
              return activeIndex === index ? 0 : 1;
            },
            duration: 0.5,
          ease: "power2.out",
        },
        "<"
      );
  },

  // Initialize PC Swiper
  initPCSwiper() {
    var specialOfferContainer = document.querySelector(
      ".special-offer__list .swiper"
    );
    
    console.log('PC Swiper Container:', specialOfferContainer);
    
    if (specialOfferContainer) {
      // Check if we have enough slides for loop
      var slides = specialOfferContainer.querySelectorAll('.swiper-slide');
      var hasEnoughSlides = slides.length >= 3; // Need at least 3 slides for loop
      
      console.log('Slides found:', slides.length, 'Has enough for loop:', hasEnoughSlides);
      
      // Calculate dynamic slidesPerView based on total slides
      var dynamicSlidesPerView = Math.max(1, Math.min(slides.length - 1, 4.8)); // Balanced: show more slides but prevent cutting
      
      console.log('Dynamic slidesPerView:', dynamicSlidesPerView);
      
      var specialOfferSwiper = new Swiper(".special-offer__list .swiper", {
        speed: 800,
        grabCursor: true,
        breakpoints: {
          0: {
            slidesPerView: 1.2,
            spaceBetween: 20,
          },
          768: {
            slidesPerView: dynamicSlidesPerView, // Dynamic slidesPerView based on total slides
            spaceBetween: 30, // Minimal space to maximize slide visibility
          },
        },
        spaceBetween: 20,
        loop: true, // Enable loop to swipe through all slides infinitely
       
        updateOnWindowResize: true,
        on: {
          init: (swiper) => {
            console.log('PC Swiper initialized:', swiper);
            this.animation(swiper, swiper.activeIndex);
          },
          slideChange: (swiper) => {
            console.log('PC Swiper slide changed to:', swiper.activeIndex);
            this.animation(swiper, swiper.activeIndex);
          },
        },
      });
      
      console.log('PC Swiper created:', specialOfferSwiper);
      return specialOfferSwiper;
      } else {
        console.log('PC Swiper container not found');
      }
      return null;
  },

  // Initialize function
  init() {
    return this.initPCSwiper();
  }
};

export default pcSwiper;
